﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            RaceMotorcycle rm = new(180, 60);
            FamilyCar fc = new(90, 80);
        }
    }
}
