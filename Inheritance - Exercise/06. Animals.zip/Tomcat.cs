﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class Tomcat : Cat
    {
        public override string ProduceSound() => "MEOW";
        public const string Gender = "Male";
        public Tomcat(string name, int age) : base(name, age, Gender) { }
    }
}
