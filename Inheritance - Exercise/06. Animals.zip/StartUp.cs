﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;

namespace Animals
{
    public class StartUp
    {
        public static void Main()
        {
            List<Animal> animals = new List<Animal>();
            while (true)
            {
                string animal = Console.ReadLine();
                if (animal == "Beast!")
                {
                    break;
                }
                var charcahteristic = Console.ReadLine().Split().ToArray();
                try
                {
                    switch (animal)
                    {
                        case "Cat":
                            {
                                Cat cat = new Cat(charcahteristic[0], int.Parse(charcahteristic[1]), charcahteristic[2]);
                                Console.WriteLine(cat.ToString());
                                animals.Add(cat);
                                break;
                            }
                        case "Dog":
                            {
                                Dog dog = new Dog(charcahteristic[0], int.Parse(charcahteristic[1]), charcahteristic[2]);
                                Console.WriteLine(dog.ToString());
                                animals.Add(dog);
                                break;
                            }
                        case "Frog":
                            {
                                Frog frog = new Frog(charcahteristic[0], int.Parse(charcahteristic[1]), charcahteristic[2]);
                                Console.WriteLine(frog.ToString());
                                animals.Add(frog);
                                break;
                            }
                        case "Kitten":
                            {
                                Kitten kitten = new Kitten(charcahteristic[0], int.Parse(charcahteristic[1]));
                                Console.WriteLine(kitten.ToString());
                                animals.Add(kitten);
                                break;
                            }
                        case "Tomcat":
                            {
                                Tomcat tomcat = new Tomcat(charcahteristic[0], int.Parse(charcahteristic[1]));
                                Console.WriteLine(tomcat.ToString());
                                animals.Add(tomcat);
                                break;
                            }
                        default:
                            {
                                throw new ArgumentException("Invalid input!");
                            }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
