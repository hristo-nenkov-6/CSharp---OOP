﻿namespace FoodShortage
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IBuyer> list = new List<IBuyer>();
            int n = int.Parse(Console.ReadLine());
            for(int i = 0; i < n; i++)
            {
                var input = Console.ReadLine().Split().ToList();
                if(input.Count == 4)
                {
                    IBuyer citizen = new Citizen(input[0], int.Parse(input[1]), input[2], input[3]);
                    list.Add(citizen);
                }
                else if(input.Count == 3) 
                {
                    IBuyer rebel = new Rebel(input[0], int.Parse(input[1]), input[2]);
                    list.Add(rebel);
                }
            }

            string name = string.Empty;
            while((name = Console.ReadLine()) != "End")
            {
                var buyer = list.FirstOrDefault(x => x.Name == name);
                if(buyer != null)
                {
                    buyer.BuyFood();
                }
            }
            
            Console.WriteLine(list.Sum(x => x.Food));
        }
    }
}