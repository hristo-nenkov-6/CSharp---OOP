﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace FoodShortage
{
    public class Citizen : IBuyer
    {
        public Citizen(string name, int age, string id, string birtDate)
        {
            Name = name;
            Age = age;
            Id = id;
            BirtDate = birtDate;
        }

        public string Name { get; private set; }
        public int Age { get; private set; }
        public string Id { get; private set; }
        public string BirtDate { get; private set; }
        public void BuyFood()
        {
            Food += 10;
        }
        public int Food { get; private set; }
    }
}
