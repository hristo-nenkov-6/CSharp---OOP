﻿using CollectionHierarchy.Models;

namespace CollectionHierarchy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            AddCollection addCollection = new AddCollection();
            AddRemoveCollection removeCollection = new AddRemoveCollection();
            MyList myList = new MyList();

            string outputLineAdd = string.Empty;
            string outputLineRemove = string.Empty;
            string outputLineMyList = string.Empty;

            foreach (var item in input)
            {
                outputLineAdd += addCollection.Add(item) + " ";
                outputLineRemove += removeCollection.Add(item) + " ";
                outputLineMyList += myList.Add(item) + " ";
            }

            Console.WriteLine(outputLineAdd);
            Console.WriteLine(outputLineRemove);
            Console.WriteLine(outputLineMyList);

            int removeOperations = int.Parse(Console.ReadLine());
            string outputRemove = string.Empty;
            string myListRemove = string.Empty;

            for(int i = 0; i < removeOperations; i++)
            { 

                outputRemove += removeCollection.Remove() + " ";
                myListRemove += myList.Remove() + " ";
            }

            Console.WriteLine(outputRemove);
            Console.WriteLine(myListRemove);
        }
    }
}