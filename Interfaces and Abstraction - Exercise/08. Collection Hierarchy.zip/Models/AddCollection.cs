﻿using CollectionHierarchy.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionHierarchy.Models
{
    public class AddCollection : IAddable
    {
        public AddCollection()
        {
            Body = new List<string>();
        }
        private readonly List<string> Body;
        public int Add(string item)
        {
            Body.Add(item);
            return Body.IndexOf(item);
        }
    }
}
