﻿using CollectionHierarchy.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionHierarchy.Models
{
    public class AddRemoveCollection : IRemovable
    {
        private readonly List<string> items;
        private const int indexOfAdd = 0;

        public AddRemoveCollection()
        {
            items = new List<string>();
        }

        public int Add(string item)
        {
            items.Insert(indexOfAdd, item);
            return indexOfAdd;
        }
        public string Remove()
        {
            string item = items[items.Count - 1];
            items.RemoveAt(items.Count - 1);
            return item;
        }
    }
}
