﻿using CollectionHierarchy.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionHierarchy.Models
{
    public class MyList : IUsable
    {
        private readonly List<string> items;
        private const int indexOfAdd = 0;
        private const int IndexOfRemove = 0;
        public MyList()
        {
            items = new List<string>();
        }
        public int Add(string item)
        {
            items.Insert(indexOfAdd, item);
            return indexOfAdd;
        }
        public string Remove()
        {
            string item = items[IndexOfRemove];
            items.RemoveAt(IndexOfRemove);
            return item;
        }
        public int Used { get; set; }
    }
}
