﻿using BorderControl.Models;
using BorderControl.Models.Interfaces;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifile> users = new();
            string input = string.Empty;
            while((input = Console.ReadLine()) != "End")
            {
                var tokens = input.Split().ToList();
                if(tokens.Count == 3)
                {
                    IIdentifile citizen = new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2]);
                    users.Add(citizen);
                }
                else if(tokens.Count == 2)
                {
                    IIdentifile robot = new Robot(tokens[0], tokens[1]);
                    users.Add(robot);
                }
            }

            string lastDigits = Console.ReadLine();
            foreach(var user in users)
            {
                string lastThreeOfId = user.Id.Substring(user.Id.Length - lastDigits.Length);
                if(lastThreeOfId == lastDigits)
                {
                    Console.WriteLine(user.Id);
                }
            }
        }
    }
}