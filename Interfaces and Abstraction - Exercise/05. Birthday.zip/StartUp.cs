﻿using BorderControl.Models;
using BorderControl.Models.Interfaces;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IBirthable> users = new();
            string input = string.Empty;
            while((input = Console.ReadLine()) != "End")
            {
                var tokens = input.Split().ToList();
                if (tokens[0] == "Citizen")
                {
                    IBirthable citizen = new Citizen(tokens[1], int.Parse(tokens[2]), tokens[3], tokens[4]);
                    users.Add(citizen);
                }
                else if(tokens[0] == "Pet")
                {
                    IBirthable pet = new Pet(tokens[1], tokens[2]);
                    users.Add(pet);
                }
            }

            string lastDigits = Console.ReadLine();
            foreach(var user in users.Where(x => x.BirthDate.Split("/")[2] == lastDigits))
            {
                Console.WriteLine(user.BirthDate);
            }
        }
    }
}