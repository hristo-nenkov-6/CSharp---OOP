﻿using MilitaryElite.Core.Interfaces;
using MilitaryElite.Enums;
using MilitaryElite.Interfaces;
using MilitaryElite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryElite.Core
{
    public class Engine : IEngine
    {
        private Dictionary<string, ISoldier> soldiers = new();
        public Engine()
        {
            soldiers = new Dictionary<string, ISoldier>();
        }
        public void Run()
        {
            string input;
            while((input = Console.ReadLine()) != "End")
            {
                ISoldier soldier = ProcessInput(input);
                soldiers.Add(soldier.Id, soldier);
            }

            foreach(var soldier in soldiers)
            {
                Console.WriteLine(soldier.Value.ToString());
            }
        }
        public ISoldier ProcessInput(string input)
        {
            string position = input.Split()[0];
            string ID = input.Split()[1];
            string firstName = input.Split()[2];
            string lastName = input.Split()[3];

            ISoldier soldier = null;
            switch(position)
            {
                case "Private":
                    {
                        soldier = GetPrivate(ID, firstName, lastName, decimal.Parse(input.Split()[4]));
                        break;
                    }
                case "LieutenantGeneral":
                    {
                        soldier = GetLeutenantGeneral(ID, firstName, lastName, input);
                        break;
                    }
                case "Engineer":
                    {
                        soldier = GetEngeneer(ID, firstName, lastName, input);
                        break;
                    }
                case "Commando":
                    {
                        soldier = GetCommando(ID, firstName, lastName, input);
                        break;
                    }
                case "Spy":
                    {
                        soldier = GetSpy(ID, firstName, lastName, input);
                        break;
                    }
            }
            return soldier;
        }
        public ISoldier GetPrivate(string id, string firstName, string lastName, decimal salary) =>
            new Private(id, firstName, lastName, salary);
        public ISoldier GetLeutenantGeneral(string id, string firstName, string lastName, string input)
        {
            decimal salary = decimal.Parse(input.Split()[4]);

            List<IPrivate> privates = new List<IPrivate>();
            for (int i = 5; i < input.Split().Length; i++)
            {
                string soldierId = input.Split()[i];
                IPrivate soldierr = (IPrivate)soldiers[soldierId];
                privates.Add(soldierr);
            }
            return new LeuthenandGeneral(id, firstName, lastName, salary, privates);
        }
        public ISoldier GetEngeneer(string id, string firstName, string lastName, string input)
        {
            decimal salary = decimal.Parse(input.Split()[4]);

            bool isValidCorps = Enum.TryParse<Corps>(input.Split()[5], out Corps corps);

            if(!isValidCorps)
            {
                throw new Exception();
            }


            List<IRepair> repairs = new List<IRepair>();
            for (int i = 6; i < input.Split().Length; i = i + 2)
            {
                string repairPart = input.Split()[i];
                int hoursWorked = int.Parse(input.Split()[i + 1]);
                IRepair repair = new Repair(repairPart, hoursWorked);
                repairs.Add(repair);
            }

            return new Engeneer(id, firstName , lastName , salary , corps,  repairs);
        }
        public ISoldier GetCommando(string id, string firstName, string lastName, string input)
        {
            decimal salary = decimal.Parse(input.Split()[4]);

            bool isValidCorps = Enum.TryParse<Corps>(input.Split()[5], out Corps corps);

            if (!isValidCorps)
            {
                throw new Exception();
            }

            List<IMission> misses = new List<IMission>();
            for (int i = 6; i < input.Split().Length; i = i + 2)
            {
                string codeName = input.Split()[i];
                string missionState = input.Split()[i + 1];

                bool isValidStates = Enum.TryParse<States>(missionState, out States states);

                if (!isValidStates)
                {
                    continue;
                }

                IMission mission = new Mission(codeName, states);
                misses.Add(mission);
            }
            return new Commando(id, firstName , lastName, salary, corps , misses);
        }
        public ISoldier GetSpy(string id, string firstName, string lastName, string input) =>
            new Spy(id, firstName, lastName, int.Parse(input.Split()[4]));
    }
}
