﻿using MilitaryElite.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryElite.Models
{
    public class LeuthenandGeneral : Private, ILeuthenandGeneral
    {
        public List<IPrivate> Privates { get; private set; }

        public LeuthenandGeneral(string id, string firstName, string lastName, decimal salary, List<IPrivate> privates)
            : base(id, firstName, lastName, salary)
        {
            Privates = privates;
        }
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Name: {FirstName} {LastName} Id: {Id} Salary: {Salary:f2}");
            sb.Append("Privates:");
            foreach (IPrivate priv in Privates)
            {
                sb.AppendLine();
                sb.Append("  " + priv.ToString());
            }
            return sb.ToString().Trim();
        }
    }
}
