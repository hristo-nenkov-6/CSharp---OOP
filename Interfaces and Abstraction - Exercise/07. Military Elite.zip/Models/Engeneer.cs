﻿using MilitaryElite.Enums;
using MilitaryElite.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryElite.Models
{
    public class Engeneer : SpecialisedSoldier, IEngeneer
    {
        public Engeneer(string id, string firstName, string lastName, decimal salary, Corps corps, List<IRepair> repairList) 
            : base(id, firstName, lastName, salary, corps)
        {
            RepairList = repairList;
        }
        public List<IRepair> RepairList { get; set; }
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Name: {FirstName} {LastName} Id: {Id} Salary: {Salary:f2}");
            sb.AppendLine($"Corps: {Corps}");
            sb.Append("Repairs:");
            foreach( var repair in RepairList )
            {
                sb.AppendLine();
                sb.Append("  " + repair.ToString());
            }
            return sb.ToString();
        }
    }
}
