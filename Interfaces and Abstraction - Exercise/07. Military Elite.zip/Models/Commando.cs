﻿using MilitaryElite.Enums;
using MilitaryElite.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryElite.Models
{
    public class Commando : SpecialisedSoldier, ICommando
    {
        public Commando(string id, string firstName, string lastName, decimal salary, Corps corps, List<IMission> missions)
            : base(id, firstName, lastName, salary, corps)
        {
            Missions = missions;
        }
        public List<IMission> Missions { get; private set; }
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Name: {FirstName} {LastName} Id: {Id} Salary: {Salary:f2}");
            sb.AppendLine($"Corps: {Corps}");
            sb.Append("Missions:");
            foreach (var mission in Missions)
            {
                sb.AppendLine();
                sb.Append("  " + mission.ToString());
            }
            return sb.ToString();
        }
    }
}
