﻿using MilitaryElite.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryElite.Models
{
    public class Spy : Soldier, ISpy
    {
        public Spy(string id, string firstName, string lastName, int codeNumber) : base(id, firstName, lastName)
        {
            Code = codeNumber;
        }
        public int Code { get; set; }
        public override string ToString()
        {
            return $"Name: {FirstName} {LastName} Id: {Id} Code Number: {Code}";
        }
    }
}
