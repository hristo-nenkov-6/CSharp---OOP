﻿namespace Telephony
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            string[] phoneNumbers = Console.ReadLine().Split().ToArray();
            string[] links = Console.ReadLine().Split().ToArray();
            ICallable phone;

            foreach(string ph in phoneNumbers)
            {
                if(ph.Length == 10)
                {
                    phone = new Smartphone();
                }
                else
                {
                    phone = new StationaryPhone();
                }

                try
                {
                    Console.WriteLine(phone.Call(ph));
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            IBrowsable browse = new Smartphone();
            foreach(string link in links)
            {
                try
                {
                    Console.WriteLine(browse.Browse(link));
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}