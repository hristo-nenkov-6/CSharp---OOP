﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telephony
{
    public class Smartphone : ICallable, IBrowsable
    {
        public string Call(string phoneNumber)
        {
            if(ValidatePhoneNumber(phoneNumber))
            {
                return $"Calling... {phoneNumber}";
            }
            else
            {
                throw new ArgumentException("Invalid number!");
            }
        }
        public string Browse(string link)
        {
            if (ValidateLink(link))
            {
                return $"Browsing: {link}!";
            }
            else
            {
                throw new ArgumentException("Invalid URL!");
            }
        }
        private bool ValidatePhoneNumber(string phoneNumber)
        {
            return phoneNumber.All(char.IsDigit);
        }
        private bool ValidateLink(string link)
        {
            return !link.Any(x => char.IsDigit(x) == true);
        }
    }
}
