﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        Dummy dummy;

        [Test]
        public void Test_DummyLosesHealthWhenAttacked()
        {
            dummy = new(100, 10);

            dummy.TakeAttack(20);

            Assert.AreEqual(80, dummy.Health);
        }

        [Test]
        public void Test_DeathDummyThrowsExceptionWhenAttacked()
        {
            dummy = new(-10, 10);

            Assert.Throws<InvalidOperationException>(
               () => dummy.TakeAttack(20));
        }
        [Test]
        public void Test_DeathDummyCanGiveXP()
        {
            dummy = new(-10, 10);
          
            Assert.AreEqual(10, dummy.GiveExperience());
        }
        [Test]
        public void Test_AliveDummyCannotGiveXP()
        {
            dummy = new(10, 10);

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(
                () => dummy.GiveExperience());
            Assert.AreEqual("Target is not dead.", ex.Message);
        }
    }
}