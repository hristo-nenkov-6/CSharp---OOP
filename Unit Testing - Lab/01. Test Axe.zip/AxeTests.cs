using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        [Test]
        public void Test_IfWeaponLosesDurabilityAfterEachAttaack()
        {
            Axe axe = new Axe(10, 10);
            Dummy dummy = new Dummy(10, 10);

            axe.Attack(dummy);
            Assert.That(axe.DurabilityPoints, Is.EqualTo(9), "Axe durabiliity doesn't change after attack.");
        }

        [Test]
        public void Test_AttackWithBrokenWeapon()
        {
            Axe axe = new Axe(10, 2);
            Dummy dummy = new Dummy(100, 10);

            axe.Attack(dummy);
            axe.Attack(dummy);

            Assert.Throws<InvalidOperationException>(
                () => axe.Attack(dummy));
        }
    }
}