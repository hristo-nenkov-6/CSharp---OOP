namespace DatabaseExtended.Tests
{
    using ExtendedDatabase;
    using NUnit.Framework;
    using System;
    using System.Security.Cryptography;
    using System.Xml.Linq;

    [TestFixture]
    public class ExtendedDatabaseTests
    {
        private Database database;

        [SetUp]
        public void SetUp()
        {
            Person[] persons =
            {
                new Person(1, "Ivan"),
                new Person(2, "Dragan"),
                new Person(3, "Petkan"),
                new Person(4, "Hristo"),
                new Person(5, "Petko"),
                new Person(6, "Momchil"),
                new Person(7, "Kris"),
                new Person(8, "Niki")
            };

            database = new Database(persons);
        }

        [Test]
        public void CheckIfCounterIsOk()
        {
            int expectedRes = 8;

            int actulResult = database.Count;

            Assert.AreEqual(expectedRes, actulResult);
        }

        [Test]
        public void Test_CheckIfxEmeentsAreAddes()
        {
            int expectedResult = 8;
            int actulResult = database.Count;

            Assert.AreEqual(expectedResult, actulResult);
        }
        [Test]
        public void Test_IfDataIsMoreThan16_ExceptionThrown()
        {
            Person[] persons =
            {
                new Person(1, "Ivan"),
                new Person(2, "Dragan"),
                new Person(3, "Petkan"),
                new Person(4, "Hristo"),
                new Person(5, "Petko"),
                new Person(6, "Momchil"),
                new Person(7, "Kris"),
                new Person(8, "Niki"),
                new Person(11, "aa"),
                new Person(22, "aaaa"),
                new Person(33, "bb"),
                new Person(44, "bbbb"),
                new Person(55, "cc"),
                new Person(66, "cccc"),
                new Person(77, "dd"),
                new Person(88, "dddd"),
                new Person(100, "ww")
            };

            ArgumentException ex = Assert.Throws<ArgumentException>(() => database = new Database(persons));
            Assert.AreEqual("Provided data length should be in range [0..16]!", ex.Message);
        }

        //Add Method
        //=================================================


        [Test]
        public void Test_AddingShouldIncreaseCounter()
        {
            Person person = new(42, "Momo");
            int expectedResult = 9;
            database.Add(person);

            int dbCounter = database.Count;
            Assert.AreEqual(expectedResult, dbCounter);
        }

        [Test]
        public void Test_IfElementsAreOver16_ExceptionShouldBeThrown()
        {
            Person[] persons =
            {
                new Person(1, "Ivan"),
                new Person(2, "Dragan"),
                new Person(3, "Petkan"),
                new Person(4, "Hristo"),
                new Person(5, "Petko"),
                new Person(6, "Momchil"),
                new Person(7, "Kris"),
                new Person(8, "Niki"),
                new Person(11, "aa"),
                new Person(22, "aaaa"),
                new Person(33, "bb"),
                new Person(44, "bbbb"),
                new Person(55, "cc"),
                new Person(66, "cccc"),
                new Person(77, "dd"),
                new Person(88, "dddd"),
            };

            Person person = new(42, "Momo");
            database = new Database(persons);

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(
                () => database.Add(person));
            Assert.AreEqual("Array's capacity must be exactly 16 integers!", ex.Message);
        }

        [Test]
        public void Test_IfElementWithSameNameIsAdded()
        {
            Person person = new Person(10000, "Dragan");

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(
                () => database.Add(person));
            Assert.AreEqual("There is already user with this username!", ex.Message);
        }

        [Test]
        public void Test_IfEleementWithSameIDIsAdded()
        {
            Person person = new Person(1, "pepi");

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(
                () => database.Add(person));
            Assert.AreEqual("There is already user with this Id!", ex.Message);
        }

        //Remove Method
        //=================================================

        [Test]
        public void Test_RemovingShouldDecreaseCounter()
        {
            int expectedResult = 7;
            database.Remove();

            int dbCounter = database.Count;
            Assert.AreEqual(expectedResult, dbCounter);
        }

        [Test]
        public void Test_IfDBCountIs0_ExceptionShouldBeThrown()
        {
            database = new Database();

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(
                () => database.Remove());
        }

        //FindBy Methods
        //=================================================

        [Test]
        [TestCase("")]
        [TestCase(null)]
        public void Test_DatabaseFindByUsernameMethodShouldThrowExceptionIfUsernameIsNull(string username)
        {
            ArgumentNullException exception = Assert.Throws<ArgumentNullException>(()
                => database.FindByUsername(username));

            Assert.AreEqual("Username parameter is null!", exception.ParamName);
        }

        [Test]
        public void Test_DatabaseFindByIdMethodShouldThrowExceptionIfIdIsNegative()
        {
            ArgumentOutOfRangeException exception = Assert.Throws<ArgumentOutOfRangeException>(()
                => database.FindById(-1));

            Assert.AreEqual("Id should be a positive number!", exception.ParamName);
        }
        [Test]
        public void Test_WhenStrangerIsSearchedByName_ThrowExpeiton()
        {
            string name = "bobo";
            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(
                () => database.FindByUsername(name));
            Assert.AreEqual("No user is present by this username!", ex.Message);
        }

        [Test]
        public void Test_WhenStrangerIsSearchedById_ThrowExpeiton()
        {
            long id = 999;
            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(
                () => database.FindById(id));
            Assert.AreEqual("No user is present by this ID!", ex.Message);
        }

        [Test]
        public void Test_WhenStrangerIsSearchedByName()
        {
            Person person = new Person(1, "Ivan");
            string name = "Ivan";
            Person found = database.FindByUsername(name);
            Assert.AreEqual(person.UserName, found.UserName);
            Assert.AreEqual(person.Id, found.Id);
        }

        [Test]
        public void Test_WhenStrangerIsSearchedById()
        {
            Person person = new Person(1, "Ivan");
            long id = 1;
            Person found = database.FindById(1);
            Assert.AreEqual(person.UserName, found.UserName);
            Assert.AreEqual(person.Id, found.Id);
        }
    }
}
