namespace Database.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class DatabaseTests
    {
        private Database database;

        [SetUp]
        public void SetUp()
        {
            database = new Database(1, 2);
        }

        [Test]
        public void Test_CreatingDatabaseCountShouldBeCorrect()
        {
            int expectedRes = 2;

            int actulResult = database.Count;

            Assert.AreEqual(expectedRes, actulResult);
        }

        [TestCase(1, 2, 3, 4, 5)]
        [TestCase(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)]
        public void Test_AddingElementsShouldWorkCorrectly_ThroughConstructor(params int[] data)
        {
            database = new Database(data);

            int[] actualDatabase = database.Fetch();

            Assert.AreEqual(data, actualDatabase);
        }

        [TestCase(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17)]
        [TestCase(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19)]
        public void Test_AddingMoreThan16ShouldThrowException_ThroughConstructor(params int[] data)
        {
            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(() => database = new Database(data));
            Assert.AreEqual("Array's capacity must be exactly 16 integers!", ex.Message);
        }

        [TestCase(10)]
        [TestCase(-13)]
        public void Test_AddingShouldIncreaseCounter(int a)
        {
            int expectedResult = 3;

            database.Add(a);

            Assert.AreEqual(expectedResult, database.Count);
        }

        [TestCase(10)]
        [TestCase(-13)]
        public void Test_ElementsShouldBeAddedToTheEndOfArray_ThroughAddMethod(int addedElement)
        {
            var expectedResult = addedElement;

            database.Add(addedElement);

            Assert.AreEqual(expectedResult, database.Fetch()[database.Count - 1]);
        }

        [Test]
        public void Test_Over16ElementsExceptionShouldBeThrown_ThroughAddMethod()
        {
            database = new Database();
            for(int i = 0; i < 16; i++)
            {
                database.Add(i);
            }

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(() => database.Add(5));
            Assert.AreEqual("Array's capacity must be exactly 16 integers!", ex.Message);
        }

        [Test]
        public void Test_RemoveMethodRemovesOnlyLastElement()
        {
            int[] expectedresult = new int[1] { 1 };

            database.Remove();

            Assert.AreEqual(expectedresult, database.Fetch());
        }

        [Test]
        public void Test_ExceptionShouldBeThrownIfElementIsRemovedFromEmptyDB()
        {
            database = new Database();

            InvalidOperationException ex = Assert.Throws<InvalidOperationException>(() => database.Remove());
            Assert.AreEqual("The collection is empty!", ex.Message);
        }

        [Test]
        public void Test_CountShouldBeDecreasedAfterRemoveMethod()
        {
            int expectedResult = 1;

            database.Remove();
            Assert.AreEqual(expectedResult, database.Count);
        }

        [Test]
        public void Test_RemovedElementShouldBeMade0()
        {
            int expectedResult = 0;

            database.Remove();
            int removedElement = database.Fetch()[database.Count - 1];
        }

        [Test]
        public void Test_FetchReturnsTheSameArray()
        {
            database = new Database();
            int[] dataArray = new int[10];

            for(int i = 0; i < 10; i++)
            {
                dataArray[i] = i;
                database.Add(dataArray[i]);
            }

            Assert.AreEqual(dataArray, database.Fetch());
        }
    }
}
