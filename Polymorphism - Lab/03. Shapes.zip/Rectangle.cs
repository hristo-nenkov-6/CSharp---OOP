﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Rectangle : Shape
    {
        private double heigth;
        private double width;

        public Rectangle(double heigth, double width)
        {
            Heigth = heigth;
            Width = width;
        }

        public double Heigth { get; set; }
        public double Width { get; set; }
        public override double CalculatePerimeter()
        {
            return 2 * Heigth + 2 * Width;
        }
        public override double CalculateArea()
        {
            return Heigth * Width;
        }
        public override string Draw()
        {
            return $"Drawing {typeof(Rectangle).Name}";
        }
    }
}
