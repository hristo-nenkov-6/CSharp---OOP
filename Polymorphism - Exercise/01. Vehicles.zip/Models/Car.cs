﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehicles.Models.Interfaces;

namespace Vehicles.Models
{
    public class Car : IVehicle
    {
        private const double airConditioner = 0.9;
        public Car(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }
        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }
        public void Drive(double distance)
        {
            if(FuelQuantity >= distance * (FuelConsumption + airConditioner))
            {
                FuelQuantity -= distance * (FuelConsumption + airConditioner);
                Console.WriteLine($"Car travelled {distance} km");
            }
            else
            {
                Console.WriteLine("Car needs refueling");
            }
        }
        public void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }
    }
}
