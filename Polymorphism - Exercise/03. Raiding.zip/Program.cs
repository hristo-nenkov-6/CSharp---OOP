﻿using Raiding.Models;
using Raiding.Models.Interface;

namespace Raiding
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IHero> list = new List<IHero>();

            int n = int.Parse(Console.ReadLine());

            for(int i = 0; i < n; i++)
            {
                string name = Console.ReadLine();
                string type = Console.ReadLine();

                switch(type)
                {
                    case "Druid":
                        {
                            Druid druid = new Druid(name);
                            list.Add(druid);
                            break;
                        }

                    case "Paladin":
                        {
                            Paladin paladin = new Paladin(name);
                            list.Add(paladin);
                            break;
                        }

                    case "Rogue":
                        {
                            Rogue rogue = new Rogue(name);
                            list.Add(rogue);
                            break;
                        }

                    case "Warrior":
                        {
                            Warrior warrior = new Warrior(name);
                            list.Add(warrior);
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid hero!");
                            n++;
                            break;
                        }
                }
            }

            double bossPower = double.Parse(Console.ReadLine());
            Console.WriteLine(FightAgainstBoss(bossPower, list));
        }

        public static string FightAgainstBoss(double powerOfBoss, List<IHero> list)
        {
            double sumOfPowers = 0;
            foreach(var hero in list)
            {
                Console.WriteLine(hero.CastAbility());
                sumOfPowers += hero.Power;
            }
            if(sumOfPowers >= powerOfBoss)
            {
                return "Victory!";
            }
            else
            {
                return "Defeat...";
            }
        }
    }
}