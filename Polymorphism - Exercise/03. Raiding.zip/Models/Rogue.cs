﻿using Raiding.Models.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raiding.Models
{
    public class Rogue : BaseHero, IHero
    {
        private const double power = 80;

        public Rogue(string name) : base(name)
        {
        }

        public double Power
        {
            get { return power; }
        }
        public override string CastAbility()
        {
            return $"{nameof(Rogue)} - {this.Name} hit for {this.Power} damage";
        }
    }
}
