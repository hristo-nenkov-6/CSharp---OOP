﻿using Raiding.Models.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raiding.Models
{
    public class Paladin : BaseHero, IHero
    {
        private const double power = 100;

        public Paladin(string name) : base(name)
        {
        }

        public double Power
        {
            get { return power; }
        }
        public override string CastAbility()
        {
            return $"{nameof(Paladin)} - {this.Name} healed for {this.Power}";
        }
    }
}
