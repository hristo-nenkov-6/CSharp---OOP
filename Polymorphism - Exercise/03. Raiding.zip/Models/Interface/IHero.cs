﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raiding.Models.Interface
{
    public interface IHero
    {
        string Name { get; }
        double Power { get; }
        string CastAbility();
    }
}
