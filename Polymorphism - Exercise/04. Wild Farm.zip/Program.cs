﻿using System.Runtime;
using WildFarm.Models.Animal;
using WildFarm.Models.Food;
using WildFarm.Models.Interfaces;

namespace WildFarm
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IAnimal> animals = new();
            string input = string.Empty;
            while((input = Console.ReadLine()) != "End")
            {
                var tokens = input.Split();
                string typeOfAnimal = tokens[0];
                string animalName = tokens[1];
                double animalWeight = double.Parse(tokens[2]);
                switch(typeOfAnimal)
                {
                    case "Cat":
                        {
                            string livingRegion = tokens[3];
                            string breed = tokens[4];
                            IAnimal cat = new Cat(animalName, animalWeight, livingRegion, breed);
                            Console.WriteLine(cat.AskForFood());

                            var foodTockens = Console.ReadLine().Split();
                            string typofFood = foodTockens[0];
                            double quantity = double.Parse(foodTockens[1]);
                            IFood food = ChooseFood(typofFood, quantity);

                            cat.GiveFood(food);
                            animals.Add(cat);
                            break;
                        }
                    case "Dog":
                        {
                            string livingRegion = tokens[3];
                            IAnimal dog = new Dog(animalName, animalWeight, livingRegion);
                            Console.WriteLine(dog.AskForFood());

                            var foodTockens = Console.ReadLine().Split();
                            string typofFood = foodTockens[0];
                            double quantity = double.Parse(foodTockens[1]);
                            IFood food = ChooseFood(typofFood, quantity);

                            dog.GiveFood(food);
                            animals.Add(dog);
                            break;
                        }
                    case "Hen":
                        {
                            double wingSize = double.Parse(tokens[3]);
                            IAnimal hen = new Hen(animalName, animalWeight, wingSize);
                            Console.WriteLine(hen.AskForFood());

                            var foodTockens = Console.ReadLine().Split();
                            string typofFood = foodTockens[0];
                            double quantity = double.Parse(foodTockens[1]);
                            IFood food = ChooseFood(typofFood, quantity);

                            hen.GiveFood(food);
                            animals.Add(hen);
                            break;
                        }
                    case "Mouse":
                        {
                            string livingRegion = tokens[3];
                            IAnimal mouse = new Mouse(animalName, animalWeight, livingRegion);
                            Console.WriteLine(mouse.AskForFood());

                            var foodTockens = Console.ReadLine().Split();
                            string typofFood = foodTockens[0];
                            double quantity = double.Parse(foodTockens[1]);
                            IFood food = ChooseFood(typofFood, quantity);

                            mouse.GiveFood(food);
                            animals.Add(mouse);
                            break;
                        }
                    case "Owl":
                        {
                            double wingSize = double.Parse(tokens[3]);
                            IAnimal owl = new Owl(animalName, animalWeight, wingSize);
                            Console.WriteLine(owl.AskForFood());

                            var foodTockens = Console.ReadLine().Split();
                            string typofFood = foodTockens[0];
                            double quantity = double.Parse(foodTockens[1]);
                            IFood food = ChooseFood(typofFood, quantity);

                            owl.GiveFood(food);
                            animals.Add(owl);
                            break;
                        }
                    case "Tiger":
                        {
                            string livingRegion = tokens[3];
                            string breed = tokens[4];
                            IAnimal tiger = new Tiger(animalName, animalWeight, livingRegion, breed);
                            Console.WriteLine(tiger.AskForFood());

                            var foodTockens = Console.ReadLine().Split();
                            string typofFood = foodTockens[0];
                            double quantity = double.Parse(foodTockens[1]);
                            IFood food = ChooseFood(typofFood, quantity);

                            tiger.GiveFood(food);
                            animals.Add(tiger);
                            break;
                        }
                }
            }
            foreach(var animal in animals)
            {
                Console.WriteLine(animal.ToString());
            }
        }

        public static IFood ChooseFood(string food, double foodQuantity)
        {
            IFood foodChosen = null;
            switch(food)
            {
                case "Fruit":
                    {
                        foodChosen = new Fruit(foodQuantity);
                        break;
                    }
                case "Meat":
                    {
                        foodChosen = new Meat(foodQuantity);
                        break;
                    }
                case "Seeds":
                    {
                        foodChosen = new Seeds(foodQuantity);
                        break;
                    }
                case "Vegetable":
                    {
                        foodChosen = new Vegetable(foodQuantity);
                        break;
                    }
            }
            return foodChosen;
        }
    }
}