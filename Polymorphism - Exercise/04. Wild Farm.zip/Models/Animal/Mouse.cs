﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WildFarm.Enums;
using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Animal
{
    public class Mouse : Mammal
    {
        public Mouse(string name, double weight, string livingRegion) : base(name, weight, livingRegion)
        {
        }

        public override string AskForFood()
        {
            return "Squeak";
        }
        public override string ToString()
        {
            return $"{this.GetType().Name} [{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
        }
        public override void GiveFood(IFood food)
        {
            EnumMice result;
            if (Enum.TryParse<EnumMice>(food.GetTypeString(), out result))
            {
                this.Weight += food.FoodQuantity * 0.10;
                this.FoodEaten += food.FoodQuantity;
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} does not eat {food.GetTypeString()}!");
            }
        }
    }
}
