﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WildFarm.Enums;
using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Animal
{
    public class Dog : Mammal
    {
        public Dog(string name, double weight, string livingRegion) : base(name, weight, livingRegion)
        {
        }

        public override string AskForFood()
        {
            return "Woof!";
        }
        public override string ToString()
        {
            return $"{this.GetType().Name} [{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
        }
        public override void GiveFood(IFood food)
        {
            TigerDogOwlEnum result;
            if (Enum.TryParse<TigerDogOwlEnum>(food.GetTypeString(), out result))
            {
                this.Weight += food.FoodQuantity * 0.40;
                this.FoodEaten += food.FoodQuantity;
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} does not eat {food.GetTypeString()}!");
            }
        }
    }
}
