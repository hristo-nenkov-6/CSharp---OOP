﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WildFarm.Enums;
using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Animal
{
    public class Tiger : Feline
    {
        public Tiger(string name, double weight, string livingRegion, string breed) : base(name, weight, livingRegion, breed)
        {
        }

        public override string AskForFood()
        {
            return "ROAR!!!";
        }
        public override void GiveFood(IFood food)
        {
            TigerDogOwlEnum result;
            if (Enum.TryParse<TigerDogOwlEnum>(food.GetTypeString(), out result))
            {
                this.Weight += food.FoodQuantity * 1.00;
                this.FoodEaten += food.FoodQuantity;
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} does not eat {food.GetTypeString()}!");
            }
        }
    }
}
