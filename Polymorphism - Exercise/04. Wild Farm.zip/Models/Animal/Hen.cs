﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WildFarm.Enums;
using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Animal
{
    public class Hen : Bird
    {
        public Hen(string name, double weight, double wingSize) : base(name, weight, wingSize)
        { 
        }

        public override string AskForFood()
        {
            return "Cluck";
        }
        public override void GiveFood(IFood food)
        {
            EnumHen result;
            if (Enum.TryParse<EnumHen>(food.GetTypeString(), out result))
            {
                this.Weight += food.FoodQuantity * 0.35;
                this.FoodEaten += food.FoodQuantity;
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} does not eat {food.GetTypeString()}!");
            }
        }
    }
}
