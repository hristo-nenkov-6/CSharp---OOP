﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WildFarm.Enums;
using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Animal
{
    public class Owl : Bird
    {
        public Owl(string name, double weight, double wingSize) : base(name, weight, wingSize)
        {
        }

        public override string AskForFood()
        {
            return "Hoot Hoot";
        }
        public override void GiveFood(IFood food)
        {
            TigerDogOwlEnum result;
            if (Enum.TryParse<TigerDogOwlEnum>(food.GetTypeString(), out result))
            {
                this.Weight += food.FoodQuantity * 0.25;
                this.FoodEaten += food.FoodQuantity;
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} does not eat {food.GetTypeString()}!");
            }
        }
    }
}
