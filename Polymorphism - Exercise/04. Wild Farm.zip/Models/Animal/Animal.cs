﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WildFarm.Enums;
using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Animal
{
    public abstract class Animal : IAnimal
    {
        protected Animal(string name, double weight)
        {
            Name = name;
            Weight = weight;
        }
        public string Name { get; set; }
        public double Weight { get; set; }
        public double FoodEaten = 0;
        public abstract string AskForFood();
        public abstract void GiveFood(IFood food);
    }
}
