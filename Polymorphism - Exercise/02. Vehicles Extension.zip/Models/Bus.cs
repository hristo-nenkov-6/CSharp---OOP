﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using Vehicles.Models.Interfaces;

namespace Vehicles.Models
{
    public class Bus : IVehicle
    {
        private const double airConditioner = 1.4;
        private double fuelQuantitiy;

        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            TankCapacity = tankCapacity;
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity
        {
            get => fuelQuantitiy;
            set
            {
                if(value <= TankCapacity)
                {
                    fuelQuantitiy = value;
                }
                else
                {
                    fuelQuantitiy = 0;
                }
            }
        }
        public double FuelConsumption { get; set; }
        public double TankCapacity { get; set; }
        public void Drive(double distance)
        {
            if (FuelQuantity <= TankCapacity)
            {
                if (FuelQuantity >= distance * (FuelConsumption + airConditioner))
                {
                    FuelQuantity -= distance * (FuelConsumption + airConditioner);
                    Console.WriteLine($"Bus travelled {distance} km");
                }
                else
                {
                    Console.WriteLine("Bus needs refueling");
                }
            }
        }
        public void DriveEmpty(double distance)
        {
            if (FuelQuantity <= TankCapacity)
            {
                if (FuelQuantity >= distance * (FuelConsumption))
                {
                    FuelQuantity -= distance * (FuelConsumption);
                    Console.WriteLine($"Bus travelled {distance} km");
                }
                else
                {
                    Console.WriteLine("Bus needs refueling");
                }
            }

        }
        public void Refuel(double fuel)
        {
            if (fuel > 0)
            {
                if (FuelQuantity + fuel <= TankCapacity)
                {
                    FuelQuantity += fuel;
                }
                else
                {
                    Console.WriteLine($"Cannot fit {fuel} fuel in the tank");
                }
            }
            else
            {
                Console.WriteLine("Fuel must be a positive number");
            }
        }
    }
}
