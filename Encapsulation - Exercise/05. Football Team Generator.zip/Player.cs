﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballTeamGenerator
{
    public class Player
    {
        private string name;
        private List<int> stats;
        

        public Player(string name, List<int> stats)
        {
            Name = name;
            Stats = stats;
        }

        public string Name
        {
            get { return name; }
            set
            {
                if(String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("A name should not be empty.");
                }

                name = value;
            }
        }
        public List<int> Stats
        {
            get { return stats; }
            set
            {
                
                Dictionary<string, int> dict = new();
                dict.Add("Endurance", value[0]);
                dict.Add("Sprint", value[1]);
                dict.Add("Dribble", value[2]);
                dict.Add("Passing", value[3]);
                dict.Add("Shooting", value[4]);

                foreach (var stat in dict.Keys)
                {
                    if(dict[stat] < 0 || dict[stat] > 100)
                    {
                        throw new ArgumentException($"{stat} should be between 0 and 100.");
                    }
                }
                stats = value;
            }
        }

        public double GetOverallSkill()
        {
            return stats.Average();
        }
    }
}
