﻿namespace FootballTeamGenerator
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<Team> teams = new List<Team>();
            string command = string.Empty;
            while((command = Console.ReadLine()) != "END")
            {
                var tokens = command.Split(";").ToList();
                string typeOfCommand = tokens[0];
                string teamName = tokens[1];

                try
                {
                    switch (typeOfCommand)
                    {
                        case "Team":
                            {
                                Team team = new Team(teamName);
                                teams.Add(team);
                                break;
                            }
                        case "Add":
                            {
                                Team team = teams.FirstOrDefault(t => t.Name == teamName);
                                if (team == null)
                                {
                                    throw new ArgumentException($"Team {teamName} does not exist.");
                                }

                                string playerName = tokens[2];
                                var stats = new List<int>();
                                GetStats(tokens, stats);

                                team.AddPlayer(playerName, stats);
                                break;
                            }
                        case "Remove":
                            {
                                Team team = teams.FirstOrDefault(t => t.Name == teamName);
                                if (team == null)
                                {
                                    throw new ArgumentException($"Team {teamName} does not exist.");
                                }
                                string playerName = tokens[2];

                                team.RemovePlayer(playerName);
                                break;
                            }
                        case "Rating":
                            {
                                Team team = teams.FirstOrDefault(t => t.Name == teamName);
                                if (team == null)
                                {
                                    throw new ArgumentException($"Team {teamName} does not exist.");
                                }
                                Console.WriteLine($"{teamName} - {team.Rating:f0}");
                                break;
                            }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }


            }
        }
        static void GetStats(List<string> tokens, List<int> stats)
        {
            for (int i = 3; i < 8; i++)
            {
                stats.Add(int.Parse(tokens[i]));
            }
        }
    }
}