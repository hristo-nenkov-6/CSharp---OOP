﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Class_Box_Data
{
    public class Box
    {
        private double length;
        private double width;
        private double height;
        public Box(double length, double width, double height)
        {
            Length = length;
            Width = width;
            Height = height;
        }

        public double Length
        {
            get => length;
            set
            {
                if(value > 0)
                {
                    length = value;
                }
                else
                {
                    throw new ArgumentException($"Length cannot be zero or negative.");
                }
            }
        }
        public double Width
        {
            get => width;
            set
            {
                if (value > 0)
                {
                    width = value;
                }
                else
                {
                    throw new ArgumentException($"Width cannot be zero or negative.");
                }
            }
        }
        public double Height
        {
            get => height;
            set
            {
                if (value > 0)
                {
                    height = value;
                }
                else
                {
                    throw new ArgumentException($"Height cannot be zero or negative.");
                }
            }
        }

        public double SurfaceArea()
        {
            return 2 * Height * Width + 2 * Height * Length + 2 * Width * Length;
        }
        public double LateralSurfaceArea()
        {
            return 2 * Width * Height + 2 * Length * Height;
        }
        public double Volume()
        {
            return Width * Height * Length;
        }
    }
}
