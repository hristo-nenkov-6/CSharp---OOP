﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    public class Topping
    {
        private string toppingType;
        private double grams;
        private double toppingModifier = 1;
        private const int toppinghCalsPerGramConst = 2;

        public Topping(string type, double grams)
        {
            Type = type;
            Grams = grams;
        }

        public string Type
        {
            get { return toppingType; }
            set
            {
                switch(value.ToLower())
                {
                    case "meat":
                        {
                            toppingType = value;
                            toppingModifier = 1.2;
                            break;
                        }
                    case "veggies":
                        {
                            toppingType = value;
                            toppingModifier = 0.8;
                            break;
                        }
                    case "cheese":
                        {
                            toppingType = value;
                            toppingModifier = 1.1;
                            break;
                        }
                    case "sauce":
                        {
                            toppingType = value;
                            toppingModifier = 0.9;
                            break;
                        }
                    default:
                        {
                            throw new ArgumentException($"Cannot place {value} on top of your pizza.");
                        }
                }
            }
        }

        public double Grams
        {
            get { return grams; }
            set
            {
                if (value < 1 || value > 50)
                {
                    throw new ArgumentException($"{toppingType} weight should be in the range [1..50].");
                }
                
                grams = value;
            }
        }
        
        public double Calories
        {
            get
            {
                return Grams * toppingModifier * toppinghCalsPerGramConst;
            }
        }
    }
}
