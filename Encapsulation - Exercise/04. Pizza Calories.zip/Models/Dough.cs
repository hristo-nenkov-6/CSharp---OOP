﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    public class Dough
    {
        private string flourType;
        private string bakingTechnique;
        private double grams;
        private double flourModifier = 1;
        private double bakingModifier = 1;
        private const int doughCalsPerGramConst = 2;

        public Dough(string flourType, string bakingTechnique, double grams)
        {
            FlourType = flourType;
            BakingTechnique = bakingTechnique;
            Grams = grams;
        }

        public string FlourType
        {
            get { return flourType; }
            private set
            {
                switch(value.ToLower())
                {
                    case "white":
                        {
                            flourType = value;
                            flourModifier = 1.5;
                            break;
                        }
                    case "wholegrain":
                        {
                            flourType = value;
                            flourModifier = 1.0;
                            break;
                        }
                    default:
                        {
                            throw new ArgumentException("Invalid type of dough.");
                        }
                }
            }
        }

        public string BakingTechnique
        {
            get { return bakingTechnique; }
            private set
            {
                switch(value.ToLower())
                {
                    case "crispy":
                        {
                            bakingTechnique = value;
                            bakingModifier = 0.9;
                            break;
                        }
                    case "chewy":
                        {
                            bakingTechnique = value;
                            bakingModifier = 1.1;
                            break;
                        }
                    case "homemade":
                        {
                            bakingTechnique = value;
                            bakingModifier = 1.0;
                            break;
                        }
                    default:
                        {
                            throw new ArgumentException("Invalid type of dough.");
                        }
                }
            }
        }

        public double Grams
        {
            get { return grams; }
            private set
            {
                if(value < 1 || value > 200)
                {
                    throw new ArgumentException("Dough weight should be in the range [1..200].");
                }
                grams = value;
            }
        }

        public double Calories
        {
            get { return doughCalsPerGramConst * bakingModifier * flourModifier * Grams; }
        }
    }
}
