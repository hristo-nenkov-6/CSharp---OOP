﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingSpree
{
    public class Person
    {
        private string name;
        private double money;
        private List<Product> bagOfProducts = new List<Product>();

        public List<string> BagOfProducts()
        {
            List<string> bag = new List<string>();
            for(int i = 0; i < bagOfProducts.Count; i++)
            {
                bag.Add(bagOfProducts[i].Name);
            }
            return bag;
        }
        public Person(string name, double money)
        {
            Name = name;
            Money = money;
        }

        public string Name
        {
            get { return name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Name cannot be empty");
                }

                name = value;
            }
        }

        public double Money
        {
            get { return money; }
            set
            {
                if(value < 0)
                {
                    throw new ArgumentException("Money cannot be negative");
                }

                money = value;
            }
        }

        public void Buy(Product product)
        {
            if(this.Money >= product.Cost)
            {
                bagOfProducts.Add(product);
                this.Money -= product.Cost;
                Console.WriteLine($"{this.Name} bought {product.Name}");
            }
            else
            {
                Console.WriteLine($"{this.Name} can't afford {product.Name}");
            }
        }
        public override string ToString()
        {
            if (bagOfProducts.Count == 0)
            {
                return $"{this.Name} - Nothing bought";
            }
            else
            {
                return $"{this.Name} - {String.Join(", ", this.BagOfProducts())}";
            }
        }
    }
}
