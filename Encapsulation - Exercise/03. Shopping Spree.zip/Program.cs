﻿namespace ShoppingSpree
{
    public class Program
    {
        static void Main(string[] args)
        {
            var people = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            var prods = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            List<Person> persons = new List<Person>();
            List<Product> products = new List<Product>();

            for(int i = 0; i < people.Count; i++)
            {
                try
                {
                    var person = new Person(people[i].Split("=")[0], double.Parse(people[i].Split("=")[1]));
                    persons.Add(person);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return;
                }
            }

            for (int i = 0; i < prods.Count; i++)
            {
                try
                {
                    var product = new Product(prods[i].Split("=")[0], double.Parse(prods[i].Split("=")[1]));
                    products.Add(product);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return;
                }
            }

            string input = string.Empty;
            while((input = Console.ReadLine()) != "END")
            {
                string person = input.Split()[0];
                string product = input.Split()[1];

                var objPerson = persons.FirstOrDefault(x => x.Name == person);
                var objProduct = products.FirstOrDefault(x => x.Name == product);

                objPerson.Buy(objProduct);
            }

            foreach(var person in persons)
            {
                Console.WriteLine(person.ToString());
            }
        }
    }
}