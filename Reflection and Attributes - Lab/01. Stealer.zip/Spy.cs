﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string investigatedClass, params string[] namesOfFields)
        {
            Type typeOfClass = Type.GetType(investigatedClass);
            FieldInfo[] classFields = typeOfClass.GetFields(
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);
            StringBuilder sb = new();

            Object classInstance = Activator.CreateInstance(typeOfClass, new object[] { });

            sb.AppendLine($"Class under investigation: {investigatedClass}");

            foreach(var field in classFields.Where(x => namesOfFields.Contains(x.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
